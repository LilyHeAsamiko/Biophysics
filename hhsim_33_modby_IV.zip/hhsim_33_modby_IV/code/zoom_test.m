function zoom_test(step)
global vars handles

if(step == 1) %zoom in
    zoom on
else
    zoom off
end
