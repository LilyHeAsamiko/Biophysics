function update_vgated_channel(chan)

  global vars

  update_gate(chan.varname,1,chan.gate1)
  update_gate(chan.varname,2,chan.gate2)
