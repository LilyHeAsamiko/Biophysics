function init_membrane

global handles

% Initialize

set_valbox(handles.Ki)
set_valbox(handles.Ko)
set_valbox(handles.Nai)
set_valbox(handles.Nao)
set_valbox(handles.Cli)
set_valbox(handles.Clo)
set_valbox(handles.T)
%set_valbox(handles.Rm)
set_valbox(handles.Cm)
