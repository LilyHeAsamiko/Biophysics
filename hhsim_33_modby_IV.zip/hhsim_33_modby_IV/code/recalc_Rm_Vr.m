function recalc_Rm_Vr

recalc_Rm
recalc_Vr
